// The maximum possible length (in bits) for the random bitstream.
void generate_number(uint8_t *result, uint8_t len_bits, uint32_t seed);