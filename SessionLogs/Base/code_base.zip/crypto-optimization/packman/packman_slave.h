void s_create_packet(uint8_t packet[MAX_PACK_LENGTH], uint8_t *data, uint8_t type, uint8_t length);
uint8_t s_validate_packet(uint8_t *data, uint8_t *packet);